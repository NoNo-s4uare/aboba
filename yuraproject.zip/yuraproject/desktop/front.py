import sys
import csv
from datetime import datetime
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit,
    QPushButton, QMessageBox, QListWidget, QHBoxLayout, QInputDialog,
    QFileDialog, QTextEdit
)
import requests

# БАЗОВЫЙ URL API
API_URL = "http://127.0.0.1:5000"

TOKEN = ""  # JWT токен после входа

def auth_headers():
    return {"Authorization": f"Bearer {TOKEN}"} if TOKEN else {}

class AdminApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Администрирование сувенирного магазина")
        self.resize(1100, 750)

        # Создаем основной layout один раз
        self.layout = QVBoxLayout()
        self.setLayout(self.layout)

        # элементы, которые живут всё время
        self.header = None
        self.nav_layout = None
        self.view_area = None

        # init login screen
        self.init_login_ui()

    # ----------------- Утилиты для очистки -----------------
    def clear_layout_contents(self, layout):
        """Рекурсивная очистка любого layout от всех элементов"""
        if layout is None:
            return
        # Сохраняем ссылку на layout, чтобы не удалять сам объект layout
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
            else:
                # Это вложенный layout - очищаем рекурсивно
                child_layout = item.layout()
                if child_layout:
                    self.clear_layout_contents(child_layout)
        layout.invalidate()

    def clear_view_area(self):
        """Очищает только область просмотра (view_area)"""
        if self.view_area is None:
            return
        self.clear_layout_contents(self.view_area)

    def clear_layout(self):
        """Полная очистка основного layout (для смены экранов)"""
        self.clear_layout_contents(self.layout)

    # ----------------- Логин -----------------
    def init_login_ui(self):
        # clear whole main layout and show login widgets
        self.clear_layout()

        self.layout.addWidget(QLabel("Вход сотрудника (админ/менеджер)"))

        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("Имя пользователя")
        self.layout.addWidget(self.username_input)

        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Пароль")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.layout.addWidget(self.password_input)

        btn_layout = QHBoxLayout()
        self.login_button = QPushButton("Войти")
        self.login_button.clicked.connect(self.login)
        btn_layout.addWidget(self.login_button)

        self.test_api_button = QPushButton("Проверить API")
        self.test_api_button.clicked.connect(self.test_api)
        btn_layout.addWidget(self.test_api_button)

        self.layout.addLayout(btn_layout)

    def login(self):
        global TOKEN
        username = self.username_input.text().strip()
        password = self.password_input.text().strip()
        if not username or not password:
            QMessageBox.warning(self, "Ошибка", "Введите имя пользователя и пароль")
            return
        try:
            resp = requests.post(f"{API_URL}/api/auth/login", json={"username": username, "password": password})
            data = resp.json() if resp.content else {}
            if resp.status_code == 200 and data.get("token"):
                TOKEN = data["token"]
                QMessageBox.information(self, "Успех", "Вход выполнен успешно")
                self.init_admin_ui()
            else:
                QMessageBox.warning(self, "Ошибка", data.get("message", "Не удалось войти"))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось подключиться к серверу:\n{e}")

    def test_api(self):
        try:
            r = requests.get(f"{API_URL}/api/ping")
            QMessageBox.information(self, "API", f"Ответ: {r.status_code}\n{r.text}")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось связаться с API:\n{e}")

    # ----------------- Главный админ интерфейс -----------------
    def init_admin_ui(self):
        # remove login widgets only, keep main window
        self.clear_layout()

        # Header
        self.header = QLabel("Система управления — Сувенирный магазин")
        self.header.setStyleSheet("font-size: 18px; font-weight: bold;")
        self.layout.addWidget(self.header)

        # Navigation (create once)
        self.nav_layout = QHBoxLayout()

        self.btn_products = QPushButton("Товары")
        self.btn_products.clicked.connect(self.show_products_ui)
        self.nav_layout.addWidget(self.btn_products)

        self.btn_categories = QPushButton("Категории")
        self.btn_categories.clicked.connect(self.show_categories_ui)
        self.nav_layout.addWidget(self.btn_categories)

        self.btn_suppliers = QPushButton("Поставщики")
        self.btn_suppliers.clicked.connect(self.show_suppliers_ui)
        self.nav_layout.addWidget(self.btn_suppliers)

        self.btn_stock = QPushButton("Остатки")
        self.btn_stock.clicked.connect(self.show_stock_ui)
        self.nav_layout.addWidget(self.btn_stock)

        self.btn_customers = QPushButton("Клиенты")
        self.btn_customers.clicked.connect(self.show_customers_ui)
        self.nav_layout.addWidget(self.btn_customers)

        self.btn_orders = QPushButton("Заказы")
        self.btn_orders.clicked.connect(self.show_orders_ui)
        self.nav_layout.addWidget(self.btn_orders)

        self.btn_reports = QPushButton("Отчёты")
        self.btn_reports.clicked.connect(self.show_reports_ui)
        self.nav_layout.addWidget(self.btn_reports)

        self.layout.addLayout(self.nav_layout)

        # Container area for current view widgets (create once)
        self.view_area = QVBoxLayout()
        self.layout.addLayout(self.view_area)

        # By default show products
        self.show_products_ui()

    # ----------------- Продукты -----------------
    def show_products_ui(self):
        self.clear_view_area()
        self.view_area.addWidget(QLabel("Товары (Сувениры)"))

        self.product_list = QListWidget()
        self.view_area.addWidget(self.product_list)

        btn_layout = QHBoxLayout()
        # ИЗМЕНЕНО: кнопка "Загрузить" переименована в "Обновить"
        load_btn = QPushButton("Обновить")
        load_btn.clicked.connect(self.load_products)
        btn_layout.addWidget(load_btn)

        add_btn = QPushButton("Добавить товар")
        add_btn.clicked.connect(self.add_product)
        btn_layout.addWidget(add_btn)

        edit_btn = QPushButton("Редактировать товар")
        edit_btn.clicked.connect(self.edit_product)
        btn_layout.addWidget(edit_btn)

        delete_btn = QPushButton("Удалить товар")
        delete_btn.clicked.connect(self.delete_product)
        btn_layout.addWidget(delete_btn)

        self.view_area.addLayout(btn_layout)
        
        # ИЗМЕНЕНО: автоматическая загрузка данных при открытии экрана
        self.load_products()

    def load_products(self):
        try:
            r = requests.get(f"{API_URL}/api/products", headers=auth_headers())
            if r.status_code != 200:
                QMessageBox.warning(self, "Ошибка", f"Ошибка API: {r.status_code}")
                return
                
            data = r.json()
            self.product_list.clear()
            for p in data:
                custom = "Персониф." if p.get("customizable") else ""
                self.product_list.addItem(f"{p['id']}: {p['name']} (SKU: {p.get('sku','')}) {custom} — {p.get('price',0)}")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить товары:\n{e}")

    def add_product(self):
        name, ok = QInputDialog.getText(self, "Добавить товар", "Название товара:")
        if not ok or not name:
            return
        sku, ok = QInputDialog.getText(self, "Добавить товар", "SKU:")
        if not ok:
            return
        price, ok = QInputDialog.getDouble(self, "Добавить товар", "Цена:", decimals=2)
        if not ok:
            return
        category_id, ok = QInputDialog.getInt(self, "Добавить товар", "ID категории:")
        if not ok:
            return
        supplier_id, ok = QInputDialog.getInt(self, "Добавить товар", "ID поставщика:")
        if not ok:
            return
        min_stock, ok = QInputDialog.getInt(self, "Добавить товар", "Минимальный запас:")
        if not ok:
            return
        initial_stock, ok = QInputDialog.getInt(self, "Добавить товар", "Начальный запас:")
        if not ok:
            return
        customizable_choice, ok = QInputDialog.getItem(self, "Персонализация", "Разрешить персонализацию?", ["Нет", "Да"], 0, False)
        if not ok:
            return
        customizable = customizable_choice == "Да"
        personalization_price = 0.0
        if customizable:
            personalization_price, ok = QInputDialog.getDouble(self, "Персонализация", "Цена персонализации (+):", decimals=2)
            if not ok:
                personalization_price = 0.0

        body = {
            "sku": sku,
            "name": name,
            "price": price,
            "category_id": category_id,
            "supplier_id": supplier_id,
            "min_stock": min_stock,
            "initial_stock": initial_stock,
            "customizable": customizable,
            "personalization_price": personalization_price
        }
        try:
            r = requests.post(f"{API_URL}/api/products", json=body, headers=auth_headers())
            if r.status_code in (200, 201):
                QMessageBox.information(self, "Успех", "Товар добавлен")
                # ИЗМЕНЕНО: автоматически обновляем список после добавления
                self.load_products()
            else:
                data = r.json() if r.content else {}
                QMessageBox.warning(self, "Ошибка", data.get("message", "Не удалось добавить товар"))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось подключиться к серверу:\n{e}")

    def edit_product(self):
        selected = self.product_list.currentItem()
        if not selected:
            QMessageBox.warning(self, "Ошибка", "Выберите товар")
            return
        product_id = selected.text().split(":")[0]
        try:
            r = requests.get(f"{API_URL}/api/products/{product_id}", headers=auth_headers())
            if r.status_code != 200:
                QMessageBox.warning(self, "Ошибка", "Не удалось получить данные товара")
                return
            prod = r.json()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось подключиться к серверу:\n{e}")
            return

        price, ok = QInputDialog.getDouble(self, "Редактировать цену", "Новая цена:", value=prod.get("price", 0.0), decimals=2)
        if not ok:
            return
        min_stock, ok = QInputDialog.getInt(self, "Минимальный запас", "Минимальный запас:", value=prod.get("min_stock", 0))
        if not ok:
            return
        customizable_choice, ok = QInputDialog.getItem(self, "Персонализация", "Разрешить персонализацию?", ["Нет", "Да"], 1 if prod.get("customizable") else 0, False)
        if not ok:
            return
        customizable = customizable_choice == "Да"
        personalization_price = prod.get("personalization_price", 0.0)
        if customizable:
            personalization_price, ok = QInputDialog.getDouble(self, "Цена персонализации", "Цена персонализации (+):", value=personalization_price, decimals=2)
            if not ok:
                personalization_price = prod.get("personalization_price", 0.0)

        body = {
            "price": price,
            "min_stock": min_stock,
            "customizable": customizable,
            "personalization_price": personalization_price
        }
        try:
            r = requests.put(f"{API_URL}/api/products/{product_id}", json=body, headers=auth_headers())
            if r.status_code == 200:
                QMessageBox.information(self, "Успех", "Товар обновлён")
                # ИЗМЕНЕНО: автоматически обновляем список после редактирования
                self.load_products()
            else:
                data = r.json() if r.content else {}
                QMessageBox.warning(self, "Ошибка", data.get("message", "Не удалось обновить товар"))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при обновлении:\n{e}")

    def delete_product(self):
        selected = self.product_list.currentItem()
        if not selected:
            QMessageBox.warning(self, "Ошибка", "Выберите товар")
            return
        product_id = selected.text().split(":")[0]
        confirm = QMessageBox.question(self, "Удалить товар", "Вы уверены?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if confirm != QMessageBox.StandardButton.Yes:
            return
        try:
            r = requests.delete(f"{API_URL}/api/products/{product_id}", headers=auth_headers())
            if r.status_code == 200:
                QMessageBox.information(self, "Успех", "Товар удалён")
                # ИЗМЕНЕНО: автоматически обновляем список после удаления
                self.load_products()
            else:
                data = r.json() if r.content else {}
                QMessageBox.warning(self, "Ошибка", data.get("message", "Не удалось удалить"))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при удалении:\n{e}")

    # ----------------- Категории -----------------
    def show_categories_ui(self):
        self.clear_view_area()
        self.view_area.addWidget(QLabel("Категории товаров"))

        self.category_list = QListWidget()
        self.view_area.addWidget(self.category_list)

        btn_layout = QHBoxLayout()
        # ИЗМЕНЕНО: кнопка "Загрузить" переименована в "Обновить"
        load_btn = QPushButton("Обновить")
        load_btn.clicked.connect(self.load_categories)
        btn_layout.addWidget(load_btn)

        add_btn = QPushButton("Добавить категорию")
        add_btn.clicked.connect(self.add_category)
        btn_layout.addWidget(add_btn)

        delete_btn = QPushButton("Удалить категорию")
        delete_btn.clicked.connect(self.delete_category)
        btn_layout.addWidget(delete_btn)

        self.view_area.addLayout(btn_layout)
        
        # ИЗМЕНЕНО: автоматическая загрузка данных при открытии экрана
        self.load_categories()

    def load_categories(self):
        try:
            r = requests.get(f"{API_URL}/api/categories", headers=auth_headers())
            if r.status_code != 200:
                QMessageBox.warning(self, "Ошибка", f"Ошибка API: {r.status_code}")
                return
                
            data = r.json()
            self.category_list.clear()
            for c in data:
                parent = f" (parent {c['parent_id']})" if c.get("parent_id") else ""
                self.category_list.addItem(f"{c['id']}: {c['name']}{parent}")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить категории:\n{e}")

    def add_category(self):
        name, ok = QInputDialog.getText(self, "Добавить категорию", "Название категории:")
        if not ok or not name:
            return
        parent_id, ok = QInputDialog.getInt(self, "Родительская категория", "ID родительской категории (0 = нет):", value=0)
        if not ok:
            return
        body = {"name": name, "parent_id": None if parent_id == 0 else parent_id}
        try:
            r = requests.post(f"{API_URL}/api/categories", json=body, headers=auth_headers())
            if r.status_code in (200, 201):
                QMessageBox.information(self, "Успех", "Категория добавлена")
                # ИЗМЕНЕНО: автоматически обновляем список после добавления
                self.load_categories()
            else:
                data = r.json() if r.content else {}
                QMessageBox.warning(self, "Ошибка", data.get("message", "Не удалось добавить категорию"))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при добавлении:\n{e}")

    def delete_category(self):
        selected = self.category_list.currentItem()
        if not selected:
            QMessageBox.warning(self, "Ошибка", "Выберите категорию")
            return
        category_id = selected.text().split(":")[0]
        confirm = QMessageBox.question(self, "Удалить категорию", "Удалить категорию (вместе с подкатегориями?)", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if confirm != QMessageBox.StandardButton.Yes:
            return
        try:
            r = requests.delete(f"{API_URL}/api/categories/{category_id}", headers=auth_headers())
            if r.status_code == 200:
                QMessageBox.information(self, "Успех", "Категория удалена")
                # ИЗМЕНЕНО: автоматически обновляем список после удаления
                self.load_categories()
            else:
                data = r.json() if r.content else {}
                QMessageBox.warning(self, "Ошибка", data.get("message", "Не удалось удалить"))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при удалении:\n{e}")

    # ----------------- Поставщики -----------------
    def show_suppliers_ui(self):
        self.clear_view_area()
        self.view_area.addWidget(QLabel("Поставщики"))

        self.supplier_list = QListWidget()
        self.view_area.addWidget(self.supplier_list)

        btn_layout = QHBoxLayout()
        # ИЗМЕНЕНО: кнопка "Загрузить" переименована в "Обновить"
        load_btn = QPushButton("Обновить")
        load_btn.clicked.connect(self.load_suppliers)
        btn_layout.addWidget(load_btn)

        add_btn = QPushButton("Добавить поставщика")
        add_btn.clicked.connect(self.add_supplier)
        btn_layout.addWidget(add_btn)

        delete_btn = QPushButton("Удалить поставщика")
        delete_btn.clicked.connect(self.delete_supplier)
        btn_layout.addWidget(delete_btn)

        self.view_area.addLayout(btn_layout)
        
        # ИЗМЕНЕНО: автоматическая загрузка данных при открытии экрана
        self.load_suppliers()

    def load_suppliers(self):
        try:
            r = requests.get(f"{API_URL}/api/suppliers", headers=auth_headers())
            if r.status_code != 200:
                QMessageBox.warning(self, "Ошибка", f"Ошибка API: {r.status_code}")
                return
                
            data = r.json()
            self.supplier_list.clear()
            for s in data:
                self.supplier_list.addItem(f"{s['id']}: {s['name']} (Contact: {s.get('contact','')})")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить поставщиков:\n{e}")

    def add_supplier(self):
        name, ok = QInputDialog.getText(self, "Добавить поставщика", "Имя поставщика:")
        if not ok or not name:
            return
        contact, ok = QInputDialog.getText(self, "Добавить поставщика", "Контактное лицо:")
        if not ok:
            return
        phone, ok = QInputDialog.getText(self, "Добавить поставщика", "Телефон:")
        if not ok:
            return
        body = {"name": name, "contact": contact, "phone": phone}
        try:
            r = requests.post(f"{API_URL}/api/suppliers", json=body, headers=auth_headers())
            if r.status_code in (200, 201):
                QMessageBox.information(self, "Успех", "Поставщик добавлен")
                # ИЗМЕНЕНО: автоматически обновляем список после добавления
                self.load_suppliers()
            else:
                data = r.json() if r.content else {}
                QMessageBox.warning(self, "Ошибка", data.get("message", "Не удалось добавить"))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при добавлении:\n{e}")

    def delete_supplier(self):
        selected = self.supplier_list.currentItem()
        if not selected:
            QMessageBox.warning(self, "Ошибка", "Выберите поставщика")
            return
        supplier_id = selected.text().split(":")[0]
        confirm = QMessageBox.question(self, "Удалить поставщика", "Вы уверены?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if confirm != QMessageBox.StandardButton.Yes:
            return
        try:
            r = requests.delete(f"{API_URL}/api/suppliers/{supplier_id}", headers=auth_headers())
            if r.status_code == 200:
                QMessageBox.information(self, "Успех", "Поставщик удалён")
                # ИЗМЕНЕНО: автоматически обновляем список после удаления
                self.load_suppliers()
            else:
                data = r.json() if r.content else {}
                QMessageBox.warning(self, "Ошибка", data.get("message", "Не удалось удалить"))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при удалении:\n{e}")

    # ----------------- Остатки -----------------
    def show_stock_ui(self):
        self.clear_view_area()
        self.view_area.addWidget(QLabel("Складские остатки"))

        self.stock_list = QListWidget()
        self.view_area.addWidget(self.stock_list)

        btn_layout = QHBoxLayout()
        # ИЗМЕНЕНО: кнопка "Загрузить" переименована в "Обновить"
        load_btn = QPushButton("Обновить")
        load_btn.clicked.connect(self.load_stock)
        btn_layout.addWidget(load_btn)

        adjust_btn = QPushButton("Скорректировать остаток")
        adjust_btn.clicked.connect(self.adjust_stock)
        btn_layout.addWidget(adjust_btn)

        alerts_btn = QPushButton("Показать низкие остатки")
        alerts_btn.clicked.connect(self.show_stock_alerts)
        btn_layout.addWidget(alerts_btn)

        self.view_area.addLayout(btn_layout)
        
        # ИЗМЕНЕНО: автоматическая загрузка данных при открытии экрана
        self.load_stock()

    def load_stock(self):
        try:
            r = requests.get(f"{API_URL}/api/stocks", headers=auth_headers())
            if r.status_code != 200:
                QMessageBox.warning(self, "Ошибка", f"Ошибка API: {r.status_code}")
                return
                
            data = r.json()
            self.stock_list.clear()
            for s in data:
                pid = s.get('product_id') or s.get('part_id') or s.get('id')
                name = s.get('name') or s.get('product_name') or ""
                sku = s.get('sku', '')
                qty = s.get('quantity') or s.get('in_stock') or 0
                min_stock = s.get('min_stock', 0)
                self.stock_list.addItem(f"{pid}: {name} (SKU: {sku}) — {qty} шт. (min {min_stock})")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить остатки:\n{e}")

    def adjust_stock(self):
        selected = self.stock_list.currentItem()
        if not selected:
            QMessageBox.warning(self, "Ошибка", "Выберите позицию склада")
            return
        part_id = selected.text().split(":")[0]
        new_qty, ok = QInputDialog.getInt(self, "Корректировка остатка", "Новое количество:")
        if not ok:
            return
        body = {"quantity": new_qty}
        try:
            r = requests.put(f"{API_URL}/api/stocks/{part_id}", json=body, headers=auth_headers())
            if r.status_code == 200:
                QMessageBox.information(self, "Успех", "Остаток обновлён")
                # ИЗМЕНЕНО: автоматически обновляем список после корректировки
                self.load_stock()
            else:
                data = r.json() if r.content else {}
                QMessageBox.warning(self, "Ошибка", data.get("message", "Не удалось обновить"))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при обновлении:\n{e}")

    def show_stock_alerts(self):
        try:
            r = requests.get(f"{API_URL}/api/reports/stock_alerts", headers=auth_headers())
            if r.status_code != 200:
                QMessageBox.warning(self, "Ошибка", f"Не удалось получить отчёт: {r.status_code}")
                return
                
            data = r.json()
            if not data:
                QMessageBox.information(self, "Низкие остатки", "Все позиции в норме")
                return
            msg = "\n".join([f"{d['sku']}: {d['name']} — {d['in_stock']} шт. (min {d['min_stock']})" for d in data])
            QMessageBox.information(self, "Низкие остатки", msg)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось получить отчёт:\n{e}")

    # ----------------- Клиенты -----------------
    def show_customers_ui(self):
        self.clear_view_area()
        self.view_area.addWidget(QLabel("Клиенты"))

        self.customer_list = QListWidget()
        self.view_area.addWidget(self.customer_list)

        btn_layout = QHBoxLayout()
        # ИЗМЕНЕНО: кнопка "Загрузить" переименована в "Обновить"
        load_btn = QPushButton("Обновить")
        load_btn.clicked.connect(self.load_customers)
        btn_layout.addWidget(load_btn)

        add_btn = QPushButton("Добавить клиента")
        add_btn.clicked.connect(self.add_customer)
        btn_layout.addWidget(add_btn)

        edit_btn = QPushButton("Редактировать клиента")
        edit_btn.clicked.connect(self.edit_customer)
        btn_layout.addWidget(edit_btn)

        delete_btn = QPushButton("Удалить клиента")
        delete_btn.clicked.connect(self.delete_customer)
        btn_layout.addWidget(delete_btn)

        self.view_area.addLayout(btn_layout)
        
        # ИЗМЕНЕНО: автоматическая загрузка данных при открытии экрана
        self.load_customers()

    def load_customers(self):
        try:
            r = requests.get(f"{API_URL}/api/clients", headers=auth_headers())
            if r.status_code != 200:
                QMessageBox.warning(self, "Ошибка", f"Ошибка API: {r.status_code}")
                return
                
            data = r.json()
            self.customer_list.clear()
            for c in data:
                self.customer_list.addItem(f"{c['id']}: {c['name']} (тел: {c.get('phone','')}, email: {c.get('email','')})")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить клиентов:\n{e}")

    def add_customer(self):
        name, ok = QInputDialog.getText(self, "Добавить клиента", "Имя клиента:")
        if not ok or not name:
            return
        phone, ok = QInputDialog.getText(self, "Добавить клиента", "Телефон:")
        if not ok:
            return
        email, ok = QInputDialog.getText(self, "Добавить клиента", "Email:")
        if not ok:
            return
        body = {"name": name, "phone": phone, "email": email}
        try:
            r = requests.post(f"{API_URL}/api/clients", json=body, headers=auth_headers())
            if r.status_code in (200, 201):
                QMessageBox.information(self, "Успех", "Клиент добавлен")
                # ИЗМЕНЕНО: автоматически обновляем список после добавления
                self.load_customers()
            else:
                data = r.json() if r.content else {}
                QMessageBox.warning(self, "Ошибка", data.get("message", "Не удалось добавить клиента"))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при добавлении:\n{e}")

    def edit_customer(self):
        selected = self.customer_list.currentItem()
        if not selected:
            QMessageBox.warning(self, "Ошибка", "Выберите клиента")
            return
        customer_id = selected.text().split(":")[0]
        try:
            r = requests.get(f"{API_URL}/api/clients/{customer_id}", headers=auth_headers())
            if r.status_code != 200:
                QMessageBox.warning(self, "Ошибка", "Не удалось получить данные клиента")
                return
            cust = r.json()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при получении:\n{e}")
            return

        name, ok = QInputDialog.getText(self, "Имя клиента", "Имя:", text=cust.get("name",""))
        if not ok:
            return
        phone, ok = QInputDialog.getText(self, "Телефон", "Телефон:", text=cust.get("phone",""))
        if not ok:
            return
        email, ok = QInputDialog.getText(self, "Email", "Email:", text=cust.get("email",""))
        if not ok:
            return
        body = {"name": name, "phone": phone, "email": email}
        try:
            r = requests.put(f"{API_URL}/api/clients/{customer_id}", json=body, headers=auth_headers())
            if r.status_code == 200:
                QMessageBox.information(self, "Успех", "Клиент обновлён")
                # ИЗМЕНЕНО: автоматически обновляем список после редактирования
                self.load_customers()
            else:
                data = r.json() if r.content else {}
                QMessageBox.warning(self, "Ошибка", data.get("message", "Не удалось обновить"))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при обновлении:\n{e}")

    def delete_customer(self):
        selected = self.customer_list.currentItem()
        if not selected:
            QMessageBox.warning(self, "Ошибка", "Выберите клиента")
            return
        customer_id = selected.text().split(":")[0]
        confirm = QMessageBox.question(self, "Удалить клиента", "Вы уверены?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if confirm != QMessageBox.StandardButton.Yes:
            return
        try:
            r = requests.delete(f"{API_URL}/api/clients/{customer_id}", headers=auth_headers())
            if r.status_code == 200:
                QMessageBox.information(self, "Успех", "Клиент удалён")
                # ИЗМЕНЕНО: автоматически обновляем список после удаления
                self.load_customers()
            else:
                data = r.json() if r.content else {}
                QMessageBox.warning(self, "Ошибка", data.get("message", "Не удалось удалить"))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при удалении:\n{e}")

    # ----------------- Заказы -----------------
    def show_orders_ui(self):
        self.clear_view_area()
        self.view_area.addWidget(QLabel("Заказы"))

        self.order_list = QListWidget()
        self.view_area.addWidget(self.order_list)

        btn_layout = QHBoxLayout()
        # ИЗМЕНЕНО: кнопка "Загрузить" переименована в "Обновить"
        load_btn = QPushButton("Обновить")
        load_btn.clicked.connect(self.load_orders)
        btn_layout.addWidget(load_btn)

        create_btn = QPushButton("Создать заказ")
        create_btn.clicked.connect(self.create_order)
        btn_layout.addWidget(create_btn)

        view_btn = QPushButton("Просмотреть / изменить статус")
        view_btn.clicked.connect(self.view_order)
        btn_layout.addWidget(view_btn)

        self.view_area.addLayout(btn_layout)
        
        # ИЗМЕНЕНО: автоматическая загрузка данных при открытии экрана
        self.load_orders()

    def load_orders(self):
        try:
            r = requests.get(f"{API_URL}/api/orders", headers=auth_headers())
            if r.status_code != 200:
                QMessageBox.warning(self, "Ошибка", f"Ошибка API: {r.status_code}")
                return
                
            data = r.json()
            self.order_list.clear()
            for o in data:
                self.order_list.addItem(f"{o['id']}: Клиент {o.get('client_name','-')} — {o.get('status','-')} — итого {o.get('total',0)}")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить заказы:\n{e}")

    def create_order(self):
        try:
            r = requests.get(f"{API_URL}/api/clients", headers=auth_headers())
            if r.status_code != 200:
                QMessageBox.warning(self, "Ошибка", "Не удалось загрузить клиентов")
                return
            customers = r.json()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить клиентов:\n{e}")
            return
        if not customers:
            QMessageBox.warning(self, "Ошибка", "Нет клиентов. Добавьте клиента перед созданием заказа.")
            return
        cust_ids = [f"{c['id']}: {c['name']}" for c in customers]
        cust_choice, ok = QInputDialog.getItem(self, "Выбор клиента", "Клиент:", cust_ids, 0, False)
        if not ok:
            return
        customer_id = int(cust_choice.split(":")[0])

        order_items = []
        try:
            r = requests.get(f"{API_URL}/api/products", headers=auth_headers())
            if r.status_code != 200:
                QMessageBox.warning(self, "Ошибка", "Не удалось загрузить товары")
                return
            products = r.json()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить товары:\n{e}")
            return
        prod_map = {str(p['id']): p for p in products}
        prod_choices = [f"{p['id']}: {p['name']} (price {p.get('price',0)})" for p in products]

        while True:
            prod_choice, ok = QInputDialog.getItem(self, "Добавить позицию", "Товар (Завершить = выйти):", ["Завершить"] + prod_choices, 0, False)
            if not ok or prod_choice == "Завершить":
                break
            prod_id = int(prod_choice.split(":")[0])
            qty, ok = QInputDialog.getInt(self, "Количество", "Количество:", value=1, min=1)
            if not ok:
                break
            product = prod_map.get(str(prod_id))
            personalization_text = None
            personalization_price = 0.0
            if product and product.get("customizable"):
                personalization_text, ok = QInputDialog.getText(self, "Персонализация", "Текст персонализации (оставьте пустым, чтобы пропустить):")
                if not ok:
                    personalization_text = None
                if personalization_text:
                    personalization_price = product.get("personalization_price", 0.0)
            order_items.append({
                "product_id": prod_id,
                "quantity": qty,
                "personalization_text": personalization_text,
                "personalization_price": personalization_price
            })

        if not order_items:
            QMessageBox.warning(self, "Ошибка", "Не добавлены позиции в заказ")
            return

        note, ok = QInputDialog.getText(self, "Примечание к заказу", "Примечание (необязательно):")
        if not ok:
            note = ""

        body = {
            "client_id": customer_id,
            "items": order_items,
            "note": note
        }
        try:
            r = requests.post(f"{API_URL}/api/orders", json=body, headers=auth_headers())
            if r.status_code in (200, 201):
                resp = r.json()
                QMessageBox.information(self, "Успех", f"Заказ создан (ID: {resp.get('order_id')})")
                # ИЗМЕНЕНО: автоматически обновляем список после создания заказа
                self.load_orders()
            else:
                data = r.json() if r.content else {}
                QMessageBox.warning(self, "Ошибка", data.get("message", "Не удалось создать заказ"))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось создать заказ:\n{e}")

    def view_order(self):
        selected = self.order_list.currentItem()
        if not selected:
            QMessageBox.warning(self, "Ошибка", "Выберите заказ")
            return
        order_id = selected.text().split(":")[0]
        try:
            r = requests.get(f"{API_URL}/api/orders/{order_id}", headers=auth_headers())
            if r.status_code != 200:
                QMessageBox.warning(self, "Ошибка", "Не удалось получить заказ")
                return
            order = r.json()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при получении заказа:\n{e}")
            return

        details = f"Заказ {order.get('id')}\nКлиент: {order.get('client_name')}\nСтатус: {order.get('status')}\nДата: {order.get('date')}\n\nПозиции:\n"
        for it in order.get("items", []):
            details += f"- {it.get('product_name')} x{it.get('quantity')}  персонализация: {it.get('personalization_text') or '-'}\n"
        details += f"\nИтого: {order.get('total')}\n\nПримечание: {order.get('note','')}"
        dlg = QMessageBox(self)
        dlg.setWindowTitle(f"Заказ {order_id}")
        dlg.setText(details)
        change_status_btn = dlg.addButton("Изменить статус", QMessageBox.ButtonRole.ActionRole)
        dlg.addButton(QMessageBox.StandardButton.Close)
        dlg.exec()

        if dlg.clickedButton() == change_status_btn:
            statuses = ["new", "processing", "ready_for_pickup", "shipped", "completed", "cancelled"]
            current = order.get("status", "new")
            try:
                new_status, ok = QInputDialog.getItem(self, "Смена статуса", "Новый статус:", statuses, statuses.index(current) if current in statuses else 0, False)
            except Exception:
                new_status, ok = QInputDialog.getItem(self, "Смена статуса", "Новый статус:", statuses, 0, False)
            if not ok:
                return
            try:
                r = requests.put(f"{API_URL}/api/orders/{order_id}/status", json={"status": new_status}, headers=auth_headers())
                if r.status_code == 200:
                    QMessageBox.information(self, "Успех", "Статус изменён")
                    # ИЗМЕНЕНО: автоматически обновляем список после изменения статуса
                    self.load_orders()
                else:
                    data = r.json() if r.content else {}
                    QMessageBox.warning(self, "Ошибка", data.get("message", "Не удалось изменить статус"))
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Ошибка при смене статуса:\n{e}")

    # ----------------- Отчёты -----------------
    def show_reports_ui(self):
        self.clear_view_area()
        self.view_area.addWidget(QLabel("Отчёты и экспорт"))

        btn_layout = QHBoxLayout()
        sales_btn = QPushButton("Отчёт по продажам (загрузить)")
        sales_btn.clicked.connect(self.download_sales_report)
        btn_layout.addWidget(sales_btn)

        stock_btn = QPushButton("Отчёт по остаткам (загрузить)")
        stock_btn.clicked.connect(self.download_stock_report)
        btn_layout.addWidget(stock_btn)

        personalized_btn = QPushButton("Персонализированные заказы")
        personalized_btn.clicked.connect(self.download_personalized_report)
        btn_layout.addWidget(personalized_btn)

        self.view_area.addLayout(btn_layout)

        self.report_preview = QTextEdit()
        self.report_preview.setReadOnly(True)
        self.view_area.addWidget(self.report_preview)
        
        # Дополнительно: можно автоматически загружать какой-то базовый отчет
        # self.download_sales_report()

    def _fetch_and_preview_report(self, endpoint, preview_title):
        try:
            r = requests.get(f"{API_URL}/api/reports/{endpoint}", headers=auth_headers())
            if r.status_code != 200:
                QMessageBox.warning(self, "Ошибка", f"Не удалось получить отчёт: {r.status_code}")
                return
            data = r.json()
            text = preview_title + "\n\n"
            if isinstance(data, list):
                for row in data[:200]:
                    text += ", ".join([f"{k}: {v}" for k, v in row.items()]) + "\n"
            else:
                text += str(data)
            self.report_preview.setPlainText(text)

            save = QMessageBox.question(self, "Сохранить CSV", "Экспортировать отчёт в CSV?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if save == QMessageBox.StandardButton.Yes:
                path, _ = QFileDialog.getSaveFileName(self, "Сохранить отчёт", f"{endpoint}_{datetime.now().strftime('%Y%m%d_%H%M')}.csv", "CSV files (*.csv)")
                if path:
                    self._save_csv(data, path)
                    QMessageBox.information(self, "Сохранено", f"Отчёт сохранён в {path}")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось получить отчёт:\n{e}")

    def _save_csv(self, data, path):
        if not isinstance(data, list):
            with open(path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["data"])
                writer.writerow([str(data)])
            return
        if not data:
            with open(path, "w", newline="", encoding="utf-8") as f:
                f.write("")
            return
        keys = list({k for row in data for k in row.keys()})
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            for row in data:
                writer.writerow(row)

    def download_sales_report(self):
        self._fetch_and_preview_report("sales", "Отчёт по продажам")

    def download_stock_report(self):
        self._fetch_and_preview_report("stocks", "Отчёт по остаткам")

    def download_personalized_report(self):
        self._fetch_and_preview_report("personalized_orders", "Отчёт по персонализированным заказам")

    # ----------------- Утилиты -----------------
    def closeEvent(self, event):
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = AdminApp()
    window.show()
    sys.exit(app.exec())