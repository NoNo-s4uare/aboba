#!/usr/bin/env python
"""
Скрипт для полной очистки базы данных
Просто запустите: python clear_db.py
"""

import sqlalchemy
from sqlalchemy import create_engine, MetaData, text

# НАСТРОЙКА MySQL
DATABASE_URI = "mysql+pymysql://root:1111@localhost/souvenirs_db?charset=utf8mb4"

def clear_database():
    """Полная очистка базы данных - удаление всех данных из всех таблиц"""
    print("Начало очистки базы данных...")
    
    # Создаем движок и подключаемся к базе данных
    engine = create_engine(DATABASE_URI)
    
    # Для MySQL сначала отключаем проверку внешних ключей
    with engine.connect() as conn:
        conn.execute(text("SET FOREIGN_KEY_CHECKS = 0"))
        conn.commit()
    
    # Получаем метаданные и список всех таблиц
    metadata = MetaData()
    metadata.reflect(bind=engine)
    tables = list(reversed(metadata.sorted_tables))
    
    print(f"Найдено таблиц для очистки: {len(tables)}")
    
    # Удаляем данные из всех таблиц
    with engine.connect() as conn:
        for table in tables:
            try:
                conn.execute(text(f"DELETE FROM {table.name}"))
                print(f"  - Очищена таблица: {table.name}")
            except Exception as e:
                print(f"  ! Ошибка при очистке таблицы {table.name}: {str(e)}")
        
        # Сбрасываем автоинкремент
        for table in tables:
            try:
                conn.execute(text(f"ALTER TABLE {table.name} AUTO_INCREMENT = 1"))
            except Exception:
                pass
        
        conn.commit()
    
    # Для MySQL включаем проверку внешних ключей обратно
    with engine.connect() as conn:
        conn.execute(text("SET FOREIGN_KEY_CHECKS = 1"))
        conn.commit()
    
    print("База данных успешно очищена!")

if __name__ == "__main__":
    print("=" * 50)
    print("СКРИПТ ОЧИСТКИ БАЗЫ ДАННЫХ")
    print("=" * 50)
    
    response = input("Вы действительно хотите полностью очистить базу данных? (y/n): ")
    if response.lower() == 'y':
        clear_database()
        print("\nОчистка завершена!")
    else:
        print("\nОчистка отменена.")
    
    print("=" * 50)