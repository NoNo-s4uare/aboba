import random
import string
from datetime import datetime, timedelta
from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session
import pymysql
import sys

# Добавляем путь к проекту, чтобы можно было импортировать модели
import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Импортируем модели из api.py
try:
    # Пытаемся импортировать модели напрямую из api.py
    from api import User, Category, Supplier, Product, Stock, Client, Order, OrderItem
except ImportError:
    # Если прямой импорт не работает, определяем модели здесь
    print("Модели не найдены в api.py, определяем их здесь...")
    
    from sqlalchemy import Column, Integer, String, Float, Boolean, ForeignKey, DateTime, Text
    from sqlalchemy.orm import declarative_base, relationship
    
    Base = declarative_base()
    
    class User(Base):
        __tablename__ = 'user'
        id = Column(Integer, primary_key=True)
        username = Column(String(80), unique=True)
        password = Column(String(120))
        role = Column(String(20), default="employee")
        
        def to_dict(self):
            return {
                "id": self.id,
                "username": self.username,
                "role": self.role
            }
    
    class Category(Base):
        __tablename__ = 'category'
        id = Column(Integer, primary_key=True)
        name = Column(String(100))
        parent_id = Column(Integer, ForeignKey("category.id"), nullable=True)
        parent = relationship("Category", remote_side=[id], backref="children")
        
        def to_dict(self):
            return {
                "id": self.id,
                "name": self.name,
                "parent_id": self.parent_id
            }
    
    class Supplier(Base):
        __tablename__ = 'supplier'
        id = Column(Integer, primary_key=True)
        name = Column(String(100))
        contact = Column(String(100))
        phone = Column(String(50))
        
        def to_dict(self):
            return {
                "id": self.id,
                "name": self.name,
                "contact": self.contact,
                "phone": self.phone
            }
    
    class Product(Base):
        __tablename__ = 'product'
        id = Column(Integer, primary_key=True)
        sku = Column(String(50), unique=True)
        name = Column(String(100))
        price = Column(Float)
        category_id = Column(Integer, ForeignKey("category.id"))
        supplier_id = Column(Integer, ForeignKey("supplier.id"))
        min_stock = Column(Integer, default=0)
        customizable = Column(Boolean, default=False)
        personalization_price = Column(Float, default=0.0)
        
        category = relationship("Category")
        supplier = relationship("Supplier")
        
        def to_dict(self):
            return {
                "id": self.id,
                "sku": self.sku,
                "name": self.name,
                "price": self.price,
                "category_id": self.category_id,
                "supplier_id": self.supplier_id,
                "min_stock": self.min_stock,
                "customizable": self.customizable,
                "personalization_price": self.personalization_price
            }
    
    class Stock(Base):
        __tablename__ = 'stock'
        id = Column(Integer, primary_key=True)
        product_id = Column(Integer, ForeignKey("product.id"))
        quantity = Column(Integer, default=0)
        
        product = relationship("Product")
        
        def to_dict(self):
            return {
                "id": self.id,
                "product_id": self.product_id,
                "quantity": self.quantity
            }
    
    class Client(Base):
        __tablename__ = 'client'
        id = Column(Integer, primary_key=True)
        name = Column(String(100))
        phone = Column(String(50))
        email = Column(String(100))
        
        def to_dict(self):
            return {
                "id": self.id,
                "name": self.name,
                "phone": self.phone,
                "email": self.email
            }
    
    class Order(Base):
        __tablename__ = 'order'
        id = Column(Integer, primary_key=True)
        client_id = Column(Integer, ForeignKey("client.id"))
        date = Column(DateTime, default=datetime.utcnow)
        status = Column(String(50), default="new")
        note = Column(Text)
        
        client = relationship("Client")
        
        def to_dict(self):
            return {
                "id": self.id,
                "client_id": self.client_id,
                "client_name": self.client.name if self.client else "Неизвестный клиент",
                "status": self.status,
                "date": self.date.isoformat() if self.date else None,
                "note": self.note
            }
    
    class OrderItem(Base):
        __tablename__ = 'order_item'
        id = Column(Integer, primary_key=True)
        order_id = Column(Integer, ForeignKey("order.id"))
        product_id = Column(Integer, ForeignKey("product.id"))
        quantity = Column(Integer)
        price = Column(Float)
        personalization_text = Column(String(200), nullable=True)
        personalization_price = Column(Float, default=0.0)
        
        order = relationship("Order")
        product = relationship("Product")
        
        def to_dict(self):
            return {
                "id": self.id,
                "order_id": self.order_id,
                "product_id": self.product_id,
                "product_name": self.product.name if self.product else "Неизвестный товар",
                "quantity": self.quantity,
                "price": self.price,
                "personalization_text": self.personalization_text,
                "personalization_price": self.personalization_price
            }

# Настройки подключения к MySQL
DB_URI = "mysql+pymysql://root:1111@localhost/souvenirs_db?charset=utf8mb4"

def generate_random_sku():
    """Генерирует случайный SKU в формате ABC-123"""
    letters = ''.join(random.choices(string.ascii_uppercase, k=3))
    numbers = ''.join(random.choices(string.digits, k=3))
    return f"{letters}-{numbers}"

def generate_random_phone():
    """Генерирует случайный российский номер телефона"""
    return f"89{random.randint(100000000, 999999999)}"

def generate_random_email(name):
    """Генерирует случайный email на основе имени"""
    domains = ["gmail.com", "yandex.ru", "mail.ru", "hotmail.com"]
    name_clean = name.lower().replace(" ", ".").replace("'", "")
    return f"{name_clean}{random.randint(1, 99)}@{random.choice(domains)}"

def init_test_data():
    """Инициализирует тестовые данные для приложения"""
    print("Начало инициализации тестовых данных...")
    
    # Создаем подключение к базе данных
    engine = create_engine(DB_URI)
    
    # Создаем сессию
    session = Session(engine)
    
    try:
        # Проверяем, есть ли уже администратор
        admin = session.execute(select(User).where(User.username == "admin")).scalar_one_or_none()
        if admin:
            print("Тестовые данные уже существуют. Пропускаем инициализацию.")
            return
        
        # Списки для генерации случайных данных
        category_names = [
            "Сувенирная продукция", "Одежда", "Посуда", "Сувениры для дома",
            "Сувениры с символикой", "Подарочные наборы", "Текстиль", "Канцелярия"
        ]
        
        supplier_names = [
            "СувенирМастер", "ПодаркиПлюс", "СувенирныйДвор", "ПромоГрад",
            "СувенирПро", "ПодаркоМир", "СувенирСтандарт", "СувенирСити"
        ]
        
        product_names = [
            "Футболка", "Кружка", "Магнит", "Открытка", "Значок", "Брелок",
            "Календарь", "Пазл", "Мышка", "Наклейка", "Ручка", "Блокнот",
            "Постер", "Коврик", "Подставка", "Медаль", "Кубок", "Флажок",
            "Плакат", "Магнит на холодильник", "Подарочный набор", "Сувенирная ложка"
        ]
        
        client_names = [
            "Иван Петров", "Мария Сидорова", "Алексей Иванов", "Екатерина Смирнова",
            "Дмитрий Кузнецов", "Ольга Васильева", "Сергей Попов", "Наталья Петрова",
            "Андрей Соколов", "Татьяна Лебедева"
        ]
        
        order_statuses = ["new", "processing", "ready_for_pickup", "shipped", "completed", "cancelled"]
        
        # Создаем администратора
        print("Создание администратора...")
        admin = User(username="admin", password="admin", role="admin")
        session.add(admin)
        
        # Создаем менеджера
        manager = User(username="manager", password="manager", role="manager")
        session.add(manager)
        
        # Создаем категории
        print("Создание категорий...")
        categories = []
        for i, name in enumerate(category_names):
            category = Category(name=name, parent_id=None)
            session.add(category)
            categories.append(category)
        
        # Добавляем подкатегории
        subcategories = [
            ("Футболки", "Одежда"),
            ("Кружки", "Посуда"),
            ("Магниты", "Сувенирная продукция"),
            ("Открытки", "Сувенирная продукция"),
            ("Значки", "Сувенирная продукция"),
            ("Брелоки", "Сувенирная продукция"),
            ("Календари", "Канцелярия"),
            ("Пазлы", "Сувениры для дома"),
            ("Мыши", "Канцелярия")
        ]
        
        for sub_name, parent_name in subcategories:
            parent = session.execute(select(Category).where(Category.name == parent_name)).scalar_one_or_none()
            if parent:
                subcategory = Category(name=sub_name, parent_id=parent.id)
                session.add(subcategory)
                categories.append(subcategory)
        
        session.flush()
        
        # Создаем поставщиков
        print("Создание поставщиков...")
        suppliers = []
        for i, name in enumerate(supplier_names):
            contact = f"Контакт {i+1}"
            phone = generate_random_phone()
            supplier = Supplier(name=name, contact=contact, phone=phone)
            session.add(supplier)
            suppliers.append(supplier)
        
        session.flush()
        
        # Создаем клиентов
        print("Создание клиентов...")
        clients = []
        for i, name in enumerate(client_names):
            phone = generate_random_phone()
            email = generate_random_email(name)
            client = Client(name=name, phone=phone, email=email)
            session.add(client)
            clients.append(client)
        
        # Добавляем одного клиента с персональными данными
        special_client = Client(
            name="ООО 'Сувенирный Мир'", 
            phone="84951234567", 
            email="info@souvenir-mir.ru"
        )
        session.add(special_client)
        clients.append(special_client)
        
        session.flush()
        
        # Создаем товары
        print("Создание товаров...")
        products = []
        for i in range(25):  # Создаем 25 разных товаров
            # Выбираем случайную категорию (включая подкатегории)
            category = random.choice(categories)
            # Выбираем случайного поставщика
            supplier = random.choice(suppliers)
            
            # Генерируем имя товара
            product_type = random.choice(product_names)
            product_name = f"{product_type} '{random.choice(['Путешествие', 'Город', 'Праздник', 'Событие', 'Память'])}'"
            
            # Генерируем цену
            base_price = random.randint(50, 1500)
            price = round(base_price / 10) * 10  # Округляем до 10
            
            # Определяем, персонализируемый ли товар
            customizable = random.choice([True, False])
            personalization_price = 0.0
            if customizable:
                personalization_price = round(random.uniform(20, 100), 2)
            
            # Создаем товар
            product = Product(
                sku=generate_random_sku(),
                name=product_name,
                price=price,
                category_id=category.id,
                supplier_id=supplier.id,
                min_stock=random.randint(5, 30),
                customizable=customizable,
                personalization_price=personalization_price
            )
            
            session.add(product)
            products.append(product)
        
        session.flush()
        
        # Создаем складские остатки
        print("Инициализация складских остатков...")
        for product in products:
            # Для некоторых товаров устанавливаем низкие остатки (для тестирования оповещений)
            if random.random() < 0.2:  # 20% товаров будут иметь низкие остатки
                quantity = random.randint(0, product.min_stock - 1)
            else:
                quantity = random.randint(product.min_stock, product.min_stock * 3)
            
            stock = Stock(product_id=product.id, quantity=quantity)
            session.add(stock)
        
        session.flush()
        
        # Создаем историю заказов для отчетов
        print("Создание истории заказов...")
        # Генерируем заказы за последние 30 дней
        for i in range(50):  # 50 заказов
            # Случайная дата в пределах последних 30 дней
            days_ago = random.randint(0, 30)
            order_date = datetime.utcnow() - timedelta(days=days_ago)
            
            # Случайный клиент
            client = random.choice(clients)
            
            # Случайный статус
            status = random.choice(order_statuses)
            
            # Примечание (иногда пустое)
            note = f"Заказ #{i+1}" if random.random() > 0.3 else ""
            
            # Создаем заказ
            order = Order(
                client_id=client.id,
                date=order_date,
                status=status,
                note=note
            )
            session.add(order)
            session.flush()
            
            # Добавляем товары в заказ (1-5 позиций)
            num_items = random.randint(1, 5)
            for _ in range(num_items):
                product = random.choice(products)
                quantity = random.randint(1, 3)
                
                # Персонализация (если товар поддерживает)
                personalization_text = None
                personalization_price = 0.0
                
                if product.customizable and random.random() > 0.3:
                    personalization_text = f"Персонализация {random.choice(['Имя', 'Дата', 'Слоган'])}"
                    personalization_price = product.personalization_price
                
                # Создаем позицию заказа
                order_item = OrderItem(
                    order_id=order.id,
                    product_id=product.id,
                    quantity=quantity,
                    price=product.price,
                    personalization_text=personalization_text,
                    personalization_price=personalization_price
                )
                session.add(order_item)
        
        # Создаем несколько заказов с персонализацией для отчета
        print("Создание заказов с персонализацией...")
        for i in range(10):
            client = random.choice(clients)
            order = Order(
                client_id=client.id,
                date=datetime.utcnow() - timedelta(days=random.randint(1, 15)),
                status="completed",
                note="Персонализированный заказ"
            )
            session.add(order)
            session.flush()
            
            # Выбираем только персонализируемые товары
            customizable_products = [p for p in products if p.customizable]
            if customizable_products:
                product = random.choice(customizable_products)
                order_item = OrderItem(
                    order_id=order.id,
                    product_id=product.id,
                    quantity=1,
                    price=product.price,
                    personalization_text=f"Текст персонализации #{i+1}",
                    personalization_price=product.personalization_price
                )
                session.add(order_item)
        
        # Создаем несколько заказов в разных статусах для тестирования
        print("Создание специальных заказов для тестирования...")
        test_client = clients[0]
        
        # Новый заказ
        new_order = Order(
            client_id=test_client.id,
            date=datetime.utcnow(),
            status="new",
            note="Новый заказ для тестирования"
        )
        session.add(new_order)
        session.flush()
        
        # Добавляем товары в новый заказ
        for i in range(2):
            product = products[i]
            order_item = OrderItem(
                order_id=new_order.id,
                product_id=product.id,
                quantity=1,
                price=product.price
            )
            session.add(order_item)
        
        # Заказ в обработке
        processing_order = Order(
            client_id=test_client.id,
            date=datetime.utcnow() - timedelta(hours=2),
            status="processing",
            note="Заказ в обработке для тестирования"
        )
        session.add(processing_order)
        session.flush()
        
        # Добавляем персонализируемый товар в заказ
        customizable_products = [p for p in products if p.customizable]
        if customizable_products:
            product = customizable_products[0]
            order_item = OrderItem(
                order_id=processing_order.id,
                product_id=product.id,
                quantity=1,
                price=product.price,
                personalization_text="Тестовая персонализация",
                personalization_price=product.personalization_price
            )
            session.add(order_item)
        
        print("Сохранение тестовых данных в базу...")
        session.commit()
        
        # Выводим сводную информацию
        print("\nТестовые данные успешно созданы:")
        print(f"- Пользователи: {len(session.execute(select(User)).scalars().all())}")
        print(f"- Категории: {len(session.execute(select(Category)).scalars().all())}")
        print(f"- Поставщики: {len(session.execute(select(Supplier)).scalars().all())}")
        print(f"- Клиенты: {len(session.execute(select(Client)).scalars().all())}")
        print(f"- Товары: {len(session.execute(select(Product)).scalars().all())}")
        print(f"- Заказы: {len(session.execute(select(Order)).scalars().all())}")
        print(f"- Складские остатки: {len(session.execute(select(Stock)).scalars().all())}")
        print("\nГотово! Теперь вы можете протестировать все функции приложения.")
        
    except Exception as e:
        print(f"Ошибка при инициализации тестовых данных: {str(e)}")
        session.rollback()
        raise
    finally:
        session.close()

if __name__ == "__main__":
    print("=" * 50)
    print("СКРИПТ ИНИЦИАЛИЗАЦИИ ТЕСТОВЫХ ДАННЫХ")
    print("=" * 50)
    
    response = input("Вы действительно хотите создать тестовые данные? (y/n): ")
    if response.lower() == 'y':
        init_test_data()
        print("\nИнициализация завершена!")
    else:
        print("\nИнициализация отменена.")
    
    print("=" * 50)