import datetime
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
import jwt
from functools import wraps
from sqlalchemy import select, update, delete
from sqlalchemy.orm import Session

# -----------------------------------------------------
# APP SETUP
# -----------------------------------------------------

app = Flask(__name__)
CORS(app)

# НАСТРОЙКА MySQL
app.config["SQLALCHEMY_DATABASE_URI"] = "mysql+pymysql://root:1111@localhost/souvenirs_db?charset=utf8mb4"
app.config["SECRET_KEY"] = "super_secret_key"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ECHO"] = False
app.config["SQLALCHEMY_POOL_RECYCLE"] = 3600
app.config["SQLALCHEMY_POOL_TIMEOUT"] = 30
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_pre_ping": True,
    "connect_args": {"charset": "utf8mb4"}
}

db = SQLAlchemy(app)

# -----------------------------------------------------
# MODELS
# -----------------------------------------------------

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True)
    password = db.Column(db.String(120))
    role = db.Column(db.String(20), default="employee")


class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    parent_id = db.Column(db.Integer, db.ForeignKey("category.id"), nullable=True)
    parent = db.relationship("Category", remote_side=[id], backref="children")
    
    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "parent_id": self.parent_id
        }


class Supplier(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    contact = db.Column(db.String(100))
    phone = db.Column(db.String(50))
    
    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "contact": self.contact,
            "phone": self.phone
        }


class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sku = db.Column(db.String(50), unique=True)
    name = db.Column(db.String(100))
    price = db.Column(db.Float)
    category_id = db.Column(db.Integer, db.ForeignKey("category.id"))
    supplier_id = db.Column(db.Integer, db.ForeignKey("supplier.id"))
    min_stock = db.Column(db.Integer, default=0)
    customizable = db.Column(db.Boolean, default=False)
    personalization_price = db.Column(db.Float, default=0.0)
    
    category = db.relationship("Category")
    supplier = db.relationship("Supplier")
    
    def to_dict(self):
        return {
            "id": self.id,
            "sku": self.sku,
            "name": self.name,
            "price": self.price,
            "category_id": self.category_id,
            "supplier_id": self.supplier_id,
            "min_stock": self.min_stock,
            "customizable": self.customizable,
            "personalization_price": self.personalization_price
        }


class Stock(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("product.id"))
    quantity = db.Column(db.Integer, default=0)
    
    product = db.relationship("Product")
    
    def to_dict(self):
        return {
            "id": self.id,
            "product_id": self.product_id,
            "quantity": self.quantity
        }


class Client(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    phone = db.Column(db.String(50))
    email = db.Column(db.String(100))
    
    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "phone": self.phone,
            "email": self.email
        }


class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("client.id"))
    date = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    status = db.Column(db.String(50), default="new")
    note = db.Column(db.String(500))
    
    client = db.relationship("Client")
    
    def to_dict(self):
        return {
            "id": self.id,
            "client_id": self.client_id,
            "client_name": self.client.name if self.client else "Неизвестный клиент",
            "status": self.status,
            "date": self.date.isoformat() if self.date else None,
            "note": self.note
        }


class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("order.id"))
    product_id = db.Column(db.Integer, db.ForeignKey("product.id"))
    quantity = db.Column(db.Integer)
    price = db.Column(db.Float)
    personalization_text = db.Column(db.String(200), nullable=True)
    personalization_price = db.Column(db.Float, default=0.0)
    
    order = db.relationship("Order")
    product = db.relationship("Product")
    
    def to_dict(self):
        return {
            "id": self.id,
            "order_id": self.order_id,
            "product_id": self.product_id,
            "product_name": self.product.name if self.product else "Неизвестный товар",
            "quantity": self.quantity,
            "price": self.price,
            "personalization_text": self.personalization_text,
            "personalization_price": self.personalization_price
        }


# -----------------------------------------------------
# AUTH HELPERS
# -----------------------------------------------------

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None

        if "Authorization" in request.headers:
            token = request.headers["Authorization"].replace("Bearer ", "")

        if not token:
            return jsonify({"message": "Token missing"}), 401

        try:
            data = jwt.decode(token, app.config["SECRET_KEY"], algorithms=["HS256"])
            user = db.session.get(User, data["user_id"])
            if not user:
                return jsonify({"message": "User not found"}), 401
        except Exception as e:
            return jsonify({"message": "Invalid token", "error": str(e)}), 401

        return f(user, *args, **kwargs)
    return decorated


# -----------------------------------------------------
# API SYSTEM ROUTES
# -----------------------------------------------------

@app.route("/api/ping")
def ping():
    return jsonify({"status": "ok"})

@app.route("/api/auth/login", methods=["POST"])
def login():
    data = request.json
    if not data or not data.get("username") or not data.get("password"):
        return jsonify({"message": "Missing credentials"}), 400
        
    user = db.session.execute(
        select(User).where(User.username == data["username"], User.password == data["password"])
    ).scalar_one_or_none()
    
    if not user:
        return jsonify({"message": "Invalid credentials"}), 401

    token = jwt.encode({
        "user_id": user.id,
        "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=12)
    }, app.config["SECRET_KEY"], algorithm="HS256")

    return jsonify({
        "token": token,
        "role": user.role,
        "username": user.username
    })


# -----------------------------------------------------
# CATEGORIES
# -----------------------------------------------------

@app.route("/api/categories", methods=["GET"])
@token_required
def get_categories(user):
    categories = db.session.execute(select(Category)).scalars().all()
    return jsonify([c.to_dict() for c in categories])


@app.route("/api/categories", methods=["POST"])
@token_required
def add_category(user):
    data = request.json
    if not data or not data.get("name"):
        return jsonify({"message": "Name is required"}), 400
        
    parent_id = data.get("parent_id")
    if parent_id == 0:
        parent_id = None
        
    cat = Category(name=data["name"], parent_id=parent_id)
    db.session.add(cat)
    db.session.commit()
    return jsonify(cat.to_dict()), 201


@app.route("/api/categories/<int:cat_id>", methods=["GET"])
@token_required
def get_category(user, cat_id):
    cat = db.session.get(Category, cat_id)
    if not cat:
        return jsonify({"message": "Category not found"}), 404
    return jsonify(cat.to_dict())


@app.route("/api/categories/<int:cat_id>", methods=["PUT"])
@token_required
def update_category(user, cat_id):
    cat = db.session.get(Category, cat_id)
    if not cat:
        return jsonify({"message": "Category not found"}), 404
        
    data = request.json
    if "name" in data:
        cat.name = data["name"]
    if "parent_id" in data:
        cat.parent_id = data["parent_id"] if data["parent_id"] != 0 else None
        
    db.session.commit()
    return jsonify(cat.to_dict())


@app.route("/api/categories/<int:cat_id>", methods=["DELETE"])
@token_required
def delete_category(user, cat_id):
    cat = db.session.get(Category, cat_id)
    if not cat:
        return jsonify({"message": "Category not found"}), 404
        
    # Сначала удаляем дочерние категории
    for child in cat.children:
        db.session.delete(child)
        
    db.session.delete(cat)
    db.session.commit()
    return jsonify({"message": "Category deleted"}), 200


# -----------------------------------------------------
# SUPPLIERS
# -----------------------------------------------------

@app.route("/api/suppliers", methods=["GET"])
@token_required
def get_suppliers(user):
    suppliers = db.session.execute(select(Supplier)).scalars().all()
    return jsonify([s.to_dict() for s in suppliers])


@app.route("/api/suppliers", methods=["POST"])
@token_required
def add_supplier(user):
    data = request.json
    if not data or not data.get("name"):
        return jsonify({"message": "Name is required"}), 400
        
    sup = Supplier(
        name=data["name"],
        contact=data.get("contact", ""),
        phone=data.get("phone", "")
    )
    db.session.add(sup)
    db.session.commit()
    return jsonify(sup.to_dict()), 201


@app.route("/api/suppliers/<int:sup_id>", methods=["GET"])
@token_required
def get_supplier(user, sup_id):
    sup = db.session.get(Supplier, sup_id)
    if not sup:
        return jsonify({"message": "Supplier not found"}), 404
    return jsonify(sup.to_dict())


@app.route("/api/suppliers/<int:sup_id>", methods=["PUT"])
@token_required
def update_supplier(user, sup_id):
    sup = db.session.get(Supplier, sup_id)
    if not sup:
        return jsonify({"message": "Supplier not found"}), 404
        
    data = request.json
    if "name" in data:
        sup.name = data["name"]
    if "contact" in data:
        sup.contact = data["contact"]
    if "phone" in data:
        sup.phone = data["phone"]
        
    db.session.commit()
    return jsonify(sup.to_dict())


@app.route("/api/suppliers/<int:sup_id>", methods=["DELETE"])
@token_required
def delete_supplier(user, sup_id):
    sup = db.session.get(Supplier, sup_id)
    if not sup:
        return jsonify({"message": "Supplier not found"}), 404
        
    db.session.delete(sup)
    db.session.commit()
    return jsonify({"message": "Supplier deleted"}), 200


# -----------------------------------------------------
# PRODUCTS
# -----------------------------------------------------

@app.route("/api/products", methods=["GET"])
@token_required
def get_products(user):
    products = db.session.execute(select(Product)).scalars().all()
    result = []
    
    for p in products:
        stock = db.session.execute(
            select(Stock).where(Stock.product_id == p.id)
        ).scalar_one_or_none()
        
        product_data = p.to_dict()
        product_data["in_stock"] = stock.quantity if stock else 0
        result.append(product_data)
        
    return jsonify(result)


@app.route("/api/products", methods=["POST"])
@token_required
def add_product(user):
    data = request.json
    required_fields = ["sku", "name", "price", "category_id", "supplier_id", "min_stock"]
    
    if not data or not all(field in data for field in required_fields):
        return jsonify({"message": f"Missing required fields: {required_fields}"}), 400

    # Проверяем существование категории и поставщика
    category = db.session.get(Category, data["category_id"])
    if not category:
        return jsonify({"message": "Category not found"}), 404
        
    supplier = db.session.get(Supplier, data["supplier_id"])
    if not supplier:
        return jsonify({"message": "Supplier not found"}), 404

    p = Product(
        sku=data["sku"],
        name=data["name"],
        price=data["price"],
        category_id=data["category_id"],
        supplier_id=data["supplier_id"],
        min_stock=data["min_stock"],
        customizable=data.get("customizable", False),
        personalization_price=data.get("personalization_price", 0.0)
    )
    db.session.add(p)
    db.session.commit()

    # Добавляем начальный остаток
    initial_stock = data.get("initial_stock", 0)
    if initial_stock > 0:
        db.session.add(Stock(product_id=p.id, quantity=initial_stock))
        db.session.commit()

    return jsonify(p.to_dict()), 201


@app.route("/api/products/<int:prod_id>", methods=["GET"])
@token_required
def get_product(user, prod_id):
    p = db.session.get(Product, prod_id)
    if not p:
        return jsonify({"message": "Product not found"}), 404
        
    stock = db.session.execute(
        select(Stock).where(Stock.product_id == prod_id)
    ).scalar_one_or_none()
    
    product_data = p.to_dict()
    product_data["in_stock"] = stock.quantity if stock else 0
    return jsonify(product_data)


@app.route("/api/products/<int:prod_id>", methods=["PUT"])
@token_required
def edit_product(user, prod_id):
    p = db.session.get(Product, prod_id)
    if not p:
        return jsonify({"message": "Product not found"}), 404

    data = request.json
    if "price" in data:
        p.price = data["price"]
    if "min_stock" in data:
        p.min_stock = data["min_stock"]
    if "name" in data:
        p.name = data["name"]
    if "sku" in data:
        p.sku = data["sku"]
    if "category_id" in data:
        category = db.session.get(Category, data["category_id"])
        if not category:
            return jsonify({"message": "Category not found"}), 404
        p.category_id = data["category_id"]
    if "supplier_id" in data:
        supplier = db.session.get(Supplier, data["supplier_id"])
        if not supplier:
            return jsonify({"message": "Supplier not found"}), 404
        p.supplier_id = data["supplier_id"]
    if "customizable" in data:
        p.customizable = data["customizable"]
    if "personalization_price" in data:
        p.personalization_price = data["personalization_price"]

    db.session.commit()
    return jsonify(p.to_dict())


@app.route("/api/products/<int:prod_id>", methods=["DELETE"])
@token_required
def delete_product(user, prod_id):
    p = db.session.get(Product, prod_id)
    if not p:
        return jsonify({"message": "Product not found"}), 404

    # Удаляем связанные остатки
    stock = db.session.execute(
        select(Stock).where(Stock.product_id == prod_id)
    ).scalar_one_or_none()
    
    if stock:
        db.session.delete(stock)
        
    db.session.delete(p)
    db.session.commit()
    return jsonify({"message": "Product removed"}), 200


# -----------------------------------------------------
# STOCKS
# -----------------------------------------------------

@app.route("/api/stocks", methods=["GET"])
@token_required
def get_stocks(user):
    stocks = db.session.execute(select(Stock)).scalars().all()
    result = []
    
    for stock in stocks:
        product = stock.product
        result.append({
            "id": stock.id,
            "product_id": stock.product_id,
            "name": product.name,
            "sku": product.sku,
            "quantity": stock.quantity,
            "min_stock": product.min_stock
        })
        
    return jsonify(result)


@app.route("/api/stocks/<int:stock_id>", methods=["PUT"])
@token_required
def update_stock(user, stock_id):
    stock = db.session.get(Stock, stock_id)
    if not stock:
        # Проверяем, может быть это ID продукта
        stock = db.session.execute(
            select(Stock).where(Stock.product_id == stock_id)
        ).scalar_one_or_none()
        
        if not stock:
            return jsonify({"message": "Stock not found"}), 404
    
    data = request.json
    if "quantity" not in data:
        return jsonify({"message": "Quantity is required"}), 400
        
    stock.quantity = data["quantity"]
    db.session.commit()
    return jsonify(stock.to_dict())


# -----------------------------------------------------
# CLIENTS
# -----------------------------------------------------

@app.route("/api/clients", methods=["GET"])
@token_required
def get_clients(user):
    clients = db.session.execute(select(Client)).scalars().all()
    return jsonify([c.to_dict() for c in clients])


@app.route("/api/clients", methods=["POST"])
@token_required
def add_client(user):
    data = request.json
    if not data or not data.get("name"):
        return jsonify({"message": "Name is required"}), 400
        
    c = Client(
        name=data["name"],
        phone=data.get("phone", ""),
        email=data.get("email", "")
    )
    db.session.add(c)
    db.session.commit()
    return jsonify(c.to_dict()), 201


@app.route("/api/clients/<int:client_id>", methods=["GET"])
@token_required
def get_client(user, client_id):
    client = db.session.get(Client, client_id)
    if not client:
        return jsonify({"message": "Client not found"}), 404
    return jsonify(client.to_dict())


@app.route("/api/clients/<int:client_id>", methods=["PUT"])
@token_required
def update_client(user, client_id):
    client = db.session.get(Client, client_id)
    if not client:
        return jsonify({"message": "Client not found"}), 404
        
    data = request.json
    if "name" in data:
        client.name = data["name"]
    if "phone" in data:
        client.phone = data["phone"]
    if "email" in data:
        client.email = data["email"]
        
    db.session.commit()
    return jsonify(client.to_dict())


@app.route("/api/clients/<int:client_id>", methods=["DELETE"])
@token_required
def delete_client(user, client_id):
    client = db.session.get(Client, client_id)
    if not client:
        return jsonify({"message": "Client not found"}), 404
        
    db.session.delete(client)
    db.session.commit()
    return jsonify({"message": "Client deleted"}), 200


# -----------------------------------------------------
# ORDERS
# -----------------------------------------------------

@app.route("/api/orders", methods=["GET"])
@token_required
def list_orders(user):
    orders = db.session.execute(select(Order)).scalars().all()
    result = []
    
    for o in orders:
        items = db.session.execute(
            select(OrderItem).where(OrderItem.order_id == o.id)
        ).scalars().all()
        
        total = sum(item.quantity * item.price + item.personalization_price for item in items)
        order_data = o.to_dict()
        order_data["total"] = total
        order_data["items"] = [item.to_dict() for item in items]
        result.append(order_data)
        
    return jsonify(result)


@app.route("/api/orders", methods=["POST"])
@token_required
def create_order(user):
    data = request.json
    
    if not data or not data.get("client_id") or not data.get("items"):
        return jsonify({"message": "Client ID and items are required"}), 400
        
    client = db.session.get(Client, data["client_id"])
    if not client:
        return jsonify({"message": "Client not found"}), 404
        
    order = Order(
        client_id=data["client_id"],
        note=data.get("note", "")
    )
    db.session.add(order)
    db.session.commit()
    
    total = 0
    for it in data["items"]:
        product = db.session.get(Product, it["product_id"])
        if not product:
            db.session.rollback()
            return jsonify({"message": f"Product with ID {it['product_id']} not found"}), 404
            
        price = it.get("price", product.price)
        quantity = it.get("quantity", 1)
        personalization_text = it.get("personalization_text", None)
        personalization_price = it.get("personalization_price", 0.0)
        
        # Проверяем остатки
        stock = db.session.execute(
            select(Stock).where(Stock.product_id == product.id)
        ).scalar_one_or_none()
        
        if not stock or stock.quantity < quantity:
            db.session.rollback()
            return jsonify({"message": f"Not enough stock for product {product.name}"}), 400
            
        # Добавляем позицию заказа
        order_item = OrderItem(
            order_id=order.id,
            product_id=product.id,
            quantity=quantity,
            price=price,
            personalization_text=personalization_text,
            personalization_price=personalization_price
        )
        db.session.add(order_item)
        
        # Уменьшаем остаток
        stock.quantity -= quantity
        total += (price * quantity) + personalization_price
    
    db.session.commit()
    return jsonify({"order_id": order.id, "total": total}), 201


@app.route("/api/orders/<int:order_id>", methods=["GET"])
@token_required
def get_order(user, order_id):
    order = db.session.get(Order, order_id)
    if not order:
        return jsonify({"message": "Order not found"}), 404
        
    items = db.session.execute(
        select(OrderItem).where(OrderItem.order_id == order_id)
    ).scalars().all()
    
    total = sum(item.quantity * item.price + item.personalization_price for item in items)
    order_data = order.to_dict()
    order_data["total"] = total
    order_data["items"] = [item.to_dict() for item in items]
    
    return jsonify(order_data)


@app.route("/api/orders/<int:order_id>/status", methods=["PUT"])
@token_required
def update_order_status(user, order_id):
    order = db.session.get(Order, order_id)
    if not order:
        return jsonify({"message": "Order not found"}), 404
        
    data = request.json
    if not data or "status" not in data:
        return jsonify({"message": "Status is required"}), 400
        
    valid_statuses = ["new", "processing", "ready_for_pickup", "shipped", "completed", "cancelled"]
    if data["status"] not in valid_statuses:
        return jsonify({"message": f"Invalid status. Valid statuses are: {valid_statuses}"}), 400
        
    order.status = data["status"]
    db.session.commit()
    
    return jsonify({"message": "Status updated", "status": order.status})


# -----------------------------------------------------
# REPORTS
# -----------------------------------------------------

@app.route("/api/reports/stock_alerts", methods=["GET"])
@token_required
def stock_alerts(user):
    products = db.session.execute(select(Product)).scalars().all()
    result = []
    
    for p in products:
        stock = db.session.execute(
            select(Stock).where(Stock.product_id == p.id)
        ).scalar_one_or_none()
        
        qty = stock.quantity if stock else 0
        if qty < p.min_stock:
            result.append({
                "sku": p.sku,
                "name": p.name,
                "in_stock": qty,
                "min_stock": p.min_stock
            })
            
    return jsonify(result)


@app.route("/api/reports/sales", methods=["GET"])
@token_required
def sales_report(user):
    order_items = db.session.execute(select(OrderItem)).scalars().all()
    result = {}
    
    for item in order_items:
        product = item.product
        if not product:
            continue
            
        if product.sku not in result:
            result[product.sku] = {
                "sku": product.sku,
                "name": product.name,
                "sold": 0,
                "revenue": 0
            }
            
        result[product.sku]["sold"] += item.quantity
        result[product.sku]["revenue"] += (item.quantity * item.price) + item.personalization_price
        
    return jsonify(list(result.values()))

@app.route("/api/reports/stocks", methods=["GET"])
@token_required
def stock_report(user):
    stocks = db.session.execute(select(Stock)).scalars().all()
    result = []
    
    for stock in stocks:
        product = stock.product
        result.append({
            "sku": product.sku,
            "name": product.name,
            "in_stock": stock.quantity,
            "min_stock": product.min_stock
        })
        
    return jsonify(result)
  
  
@app.route("/api/reports/personalized_orders", methods=["GET"])
@token_required
def personalized_orders_report(user):
    personalized_items = db.session.execute(
        select(OrderItem).where(OrderItem.personalization_text.is_not(None))
    ).scalars().all()
    
    result = []
    
    for item in personalized_items:
        order = db.session.get(Order, item.order_id)
        client = order.client if order else None
        
        result.append({
            "order_id": item.order_id,
            "client_name": client.name if client else "Неизвестный клиент",
            "product_name": item.product.name if item.product else "Неизвестный товар",  # Исправлено здесь
            "quantity": item.quantity,
            "personalization_text": item.personalization_text,
            "date": order.date.isoformat() if order and order.date else None
        })
    
    return jsonify(result)


# -----------------------------------------------------
# INIT + RUN
# -----------------------------------------------------

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        
        # Проверяем, существует ли пользователь admin
        admin = db.session.execute(
            select(User).where(User.username == "admin")
        ).scalar_one_or_none()
        
        if not admin:
            admin = User(username="admin", password="admin", role="admin")
            db.session.add(admin)
            db.session.commit()
            print("Admin user created")
        else:
            print("Admin user already exists")

    app.run(host="0.0.0.0", port=5000, debug=True)