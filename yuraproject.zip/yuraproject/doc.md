# 📚 Документация к API системы "Администрирование сувенирного магазина"

> **Версия**: 1.0  
> **Базовый URL**: `http://127.0.0.1:5000/api`

---

## 🔐 Общие сведения

API реализовано по принципам REST, работает с JSON и защищено JWT-токенами.  
Все защищённые эндпоинты требуют заголовок:
```
Authorization: Bearer <ваш_jwt_токен>
```

---

## 🔑 Аутентификация

### `POST /auth/login`
Авторизация пользователя.

**Запрос:**
```json
{
  "username": "admin",
  "password": "admin"
}
```

**Успешный ответ (200):**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "role": "admin",
  "username": "admin"
}
```

---

## 🧪 Системные эндпоинты

### `GET /ping`
Проверка доступности API.

**Ответ (200):**
```json
{"status": "ok"}
```

---

## 🏷️ Категории товаров

### `GET /categories`
Получить все категории.

**Ответ (200):**
```json
[
  {"id": 1, "name": "Футболки", "parent_id": null},
  {"id": 2, "name": "Кружки", "parent_id": null},
  {"id": 3, "name": "Хлопковые", "parent_id": 1}
]
```

### `POST /categories`
Создать категорию.

**Тело запроса:**
```json
{
  "name": "Новая категория",
  "parent_id": 1
}
```

### `PUT /categories/{id}`
Обновить категорию.

**Тело запроса:**
```json
{
  "name": "Обновлённая категория",
  "parent_id": null
}
```

### `DELETE /categories/{id}`
Удалить категорию (вместе с подкатегориями).

---

## 📦 Поставщики

### `GET /suppliers`
Получить всех поставщиков.

**Ответ (200):**
```json
[
  {
    "id": 1,
    "name": "СувенирМастер",
    "contact": "Андрей",
    "phone": "89999999999"
  }
]
```

### `POST /suppliers`
Добавить поставщика.

**Тело запроса:**
```json
{
  "name": "Новый поставщик",
  "contact": "Имя",
  "phone": "88005553535"
}
```

### `PUT /suppliers/{id}`
Обновить поставщика.

### `DELETE /suppliers/{id}`
Удалить поставщика.

---

## 🛍️ Товары

### `GET /products`
Получить список товаров с остатками.

**Ответ (200):**
```json
[
  {
    "id": 1,
    "sku": "TSHIRT-001",
    "name": "Футболка белая",
    "price": 500.0,
    "category_id": 1,
    "supplier_id": 1,
    "min_stock": 5,
    "customizable": true,
    "personalization_price": 70.0,
    "in_stock": 20
  }
]
```

### `POST /products`
Создать товар.

**Тело запроса:**
```json
{
  "sku": "MUG-001",
  "name": "Кружка",
  "price": 250.0,
  "category_id": 2,
  "supplier_id": 1,
  "min_stock": 10,
  "initial_stock": 50,
  "customizable": false,
  "personalization_price": 0.0
}
```

### `GET /products/{id}`
Получить товар по ID.

### `PUT /products/{id}`
Обновить товар (можно частично).

**Тело запроса (пример):**
```json
{
  "price": 550.0,
  "min_stock": 8
}
```

### `DELETE /products/{id}`
Удалить товар.

---

## 📊 Складские остатки

### `GET /stocks`
Получить все остатки.

**Ответ (200):**
```json
[
  {
    "id": 1,
    "product_id": 1,
    "name": "Футболка белая",
    "sku": "TSHIRT-001",
    "quantity": 20,
    "min_stock": 5
  }
]
```

### `PUT /stocks/{product_id}`
Скорректировать остаток товара.

**Тело запроса:**
```json
{"quantity": 25}
```

---

## 👤 Клиенты

### `GET /clients`
Получить всех клиентов.

**Ответ (200):**
```json
[
  {
    "id": 1,
    "name": "Иван Петров",
    "phone": "89999999999",
    "email": "ivan@example.com"
  }
]
```

### `POST /clients`
Создать клиента.

**Тело запроса:**
```json
{
  "name": "Новый клиент",
  "phone": "88005553535",
  "email": "client@example.com"
}
```

### `GET /clients/{id}`
Получить клиента по ID.

### `PUT /clients/{id}`
Обновить клиента.

### `DELETE /clients/{id}`
Удалить клиента.

---

## 📋 Заказы

### `GET /orders`
Получить все заказы.

**Ответ (200):**
```json
[
  {
    "id": 1,
    "client_id": 1,
    "client_name": "Иван Петров",
    "status": "new",
    "date": "2025-12-12T10:00:00",
    "note": "Без комментариев",
    "total": 570.0,
    "items": [
      {
        "id": 1,
        "order_id": 1,
        "product_id": 1,
        "product_name": "Футболка белая",
        "quantity": 1,
        "price": 500.0,
        "personalization_text": "Для Марии",
        "personalization_price": 70.0
      }
    ]
  }
]
```

### `POST /orders`
Создать заказ.

**Тело запроса:**
```json
{
  "client_id": 1,
  "note": "Подарок",
  "items": [
    {
      "product_id": 1,
      "quantity": 1,
      "personalization_text": "С ДР!",
      "personalization_price": 70.0
    }
  ]
}
```

### `GET /orders/{id}`
Получить заказ по ID.

### `PUT /orders/{order_id}/status`
Изменить статус заказа.

**Тело запроса:**
```json
{"status": "processing"}
```

**Допустимые статусы:**  
`new`, `processing`, `ready_for_pickup`, `shipped`, `completed`, `cancelled`

---

## 📈 Отчёты

### `GET /reports/stock_alerts`
Товары с остатком ниже минимального.

**Ответ (200):**
```json
[
  {
    "sku": "MAG-001",
    "name": "Магнит",
    "in_stock": 3,
    "min_stock": 10
  }
]
```

### `GET /reports/sales`
Отчёт по продажам.

**Ответ (200):**
```json
[
  {
    "sku": "TSHIRT-001",
    "name": "Футболка белая",
    "sold": 15,
    "revenue": 8550.0
  }
]
```

### `GET /reports/personalized_orders`
Персонализированные заказы.

**Ответ (200):**
```json
[
  {
    "order_id": 5,
    "client_name": "Иван Петров",
    "product_name": "Футболка белая",
    "quantity": 1,
    "personalization_text": "Для Марии",
    "date": "2025-12-12T10:00:00"
  }
]
```

### `GET /reports/stocks`
Отчёт по всем остаткам (для экспорта).

**Ответ (200):**
```json
[
  {
    "sku": "TSHIRT-001",
    "name": "Футболка белая",
    "in_stock": 20,
    "min_stock": 5
  }
]
```

---

## ℹ️ Особенности персонализации

- Товар помечается как персонализируемый флагом `customizable: true`
- Стоимость персонализации: `personalization_price`
- При оформлении заказа можно указать:
  - `personalization_text` — текст надписи
  - `personalization_price` — стоимость (берётся из товара на момент заказа)
- В отчётах персонализированные заказы выделяются отдельно

---

## ⚠️ Коды ошибок

| Код | Описание |
|-----|----------|
| `400` | Неверные данные запроса |
| `401` | Неавторизованный доступ (отсутствует или неверный токен) |
| `404` | Ресурс не найден |
| `500` | Внутренняя ошибка сервера |

---

> 📝 Документация сгенерирована автоматически. Последнее обновление: 12 декабря 2025 г.